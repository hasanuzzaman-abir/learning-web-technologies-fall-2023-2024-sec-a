<?php
// session_start();
// Include database connection
include_once('database.php');
// SQL Quearry
$customerManagerSql = "SELECT * FROM employee_table WHERE Status LIKE '%Customer Manager%'";
// Run SQL quearry
$customerManagerResult = mysqli_query($connection, $customerManagerSql);
// Check is the button clicked
if (isset($_POST['back'])) {
    header("location: home.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Show Product Manager</title>
</head>

<body>
    <form action="" method="post">
        <fieldset>
            <!-- Back Button -->
            <br>
            <button type="submit" name="back">Back</button>
            <hr><br>
            <table>
                <table border="1">
                    <tr>
                        <th colspan="4">
                            <h3>Customer Manager</h3>
                        </th>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Date of joining</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($customerManagerResult)) { ?>
                        <tr>
                            <td><?php echo $row["Email"]; ?></td>
                            <td><?php echo $row["Name"]; ?></td>
                            <td><?php echo $row["Status"]; ?></td>
                            <td><?php echo $row["Date"]; ?></td>
                        </tr>
                    <?php } ?>
                </table>
        </fieldset>
    </form>
</body>

</html>