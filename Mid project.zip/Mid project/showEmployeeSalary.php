<?php
// Include database connection
include_once('database.php');
// SQL Queary
$showSalarySql = "SELECT * FROM salary_table";
// Run SQL Quearry
$showSalaryResult = mysqli_query($connection, $showSalarySql);
// Back button
if (isset($_POST['back'])) {
    header("location: home.php");
    echo "Hello";
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
    <fieldset>
        <form action="" method="post">
            <!-- Back Button -->
            <br>
            <button type="submit" name="back">Back</button>
            <hr><br>
            <!-- Employee Salary table -->
            <table>
                <table border="1">
                    <tr>
                        <th colspan="4">
                            <h3>Employee Salary</h3>
                        </th>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <th>Hourly Salary</th>
                        <th>Bonous</th>
                        <th>Total Salary</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($showSalaryResult)) { ?>
                        <tr>
                            <td><?php echo $row["Email"]; ?></td>
                            <td><?php echo $row["Salary"]; ?></td>
                            <td><?php echo $row["Bonous"]; ?></td>
                            <td><?php echo $row["Total Salary"]; ?></td>
                        </tr>
                    <?php } ?>
                </table>
        </form>
    </fieldset>
</body>

</html>