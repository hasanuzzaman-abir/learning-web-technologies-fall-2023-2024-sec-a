<?php
// Include database connection
include_once('database.php');
// checking is the register button is clicked or not
if (isset($_POST['register'])) {
    // storing value in php variable
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phoneNumber = $_POST['phone_number'];
    $password = $_POST['password'];
    $date = date('Y-m-d', strtotime($_POST['date']));
    if (empty($name && $email && $phoneNumber && $password && $date)) {
        echo "Fill the form properly";
    } else {
        // quearry
        $sql = "INSERT INTO user_table VALUES ('$name', '$email', '$phoneNumber', '$password', '$date')";
        // execution of quearry
        $result = mysqli_query($connection, $sql);
        // Checking for successful data insertion
        if ($result) {
            echo "Data inserted successfully";
            header("location: login.php");
        } else {
            echo "There was an error";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Register</title>
</head>

<body>
    <div style="text-align: center;">
        <form action="" method="post">
            <fieldset>
                <!-- heading -->
                <h1>Register</h1>
                <!-- name -->
                Name: <input type="text" name="name"> <br>
                <hr>
                <!-- email -->
                Email: <input type="text" name="email"> <br>
                <hr>
                <!-- password -->
                Password: <input type="text" name="password"> <br>
                <hr>
                <!-- Phone Number -->
                Phone Number: <input type="number" name="phone_number"><br>
                <hr>
                Signin Date:
                <input type="date" name="date" /><br>
                <hr>
                <!-- submit button -->
                <button type="submit" name="register">Register</button>
                <button type="submit" name="login"><a href="login.php">Login</a></button>
            </fieldset>
        </form>
    </div>
</body>

</html>