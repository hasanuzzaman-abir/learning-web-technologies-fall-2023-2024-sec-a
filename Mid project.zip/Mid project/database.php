<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "e-commerces";
// db connection
$connection = new mysqli($servername, $username, $password, $dbname);
