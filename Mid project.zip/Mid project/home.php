<?php
session_start();
// Include database connection
include_once('database.php');
// Display Customer Order 
$customerSql = "SELECT * FROM coustomer_order";
$customerResult = mysqli_query($connection, $customerSql);
// Check Recent Employee 
if (isset($_GET['employee_number_button'])) {
    header("location: recentEmployeeAdded.php");
}
// Check all the Product Manager
if (isset($_GET['product_manager'])) {
    header("location: showProductManager.php");
}
// Check all the Customer Manager
if (isset($_GET['customer_manager'])) {
    header("location: showCustomerMnager.php");
}
// Check all recent Signin Customer
if (isset($_GET['recent_signin_customer'])) {
    header("location: recentCustomerAdded.php");
}
// Calculate salary
if (isset($_GET['employee_salary'])) {
    header("location: employeeSalary.php");
}
// Show employee salary
if (isset($_GET['show_employee_salary'])) {
    header("location: showEmployeeSalary.php");
}
// Show all employee
if (isset($_GET['employee_show_button'])) {
    header("location: showEmployee.php");
}
if (isset($_GET['revenue'])) {
    header("location: revenue.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Home</title>
</head>

<body>
    <fieldset>
        <h1 style="text-align: center;"><i>Welcome to our e-commerce</i></h1>
        <form action="" method="get">
            <hr><br>
            <!-- Button -->
            <button type="submit" name="employee_number_button">Recent Employee Added</button>
            <button type="submit" name="product_manager">Product Manager</button>
            <button type="submit" name="customer_manager">Customer Manager</button>
            <button type="submit" name="recent_signin_customer">Recently Customer Added</button>
            <button type="submit" name="employee_salary">Calculate Employee Salary</button>
            <button type="submit" name="show_employee_salary">Show Employee Salary</button>
            <button type="submit" name="revenue">Revenue</button>
            <br><br>
            <!-- Employee Table Start -->
            <hr>
            <br>
            <table border="1" class="center">
                <tr>
                    <!-- Employee Table Name -->
                    <th colspan="4">
                        <h3>Employee Table</h1>
                    </th>
                </tr>
                <!-- Employee Table Header -->
                <tr>
                    <th>Names</th>
                    <th>Add Button</th>
                    <th>Show Button</th>
                </tr>
                <!-- Employee Table Data -->
                <tr>
                    <td>Employee</td>
                    <td><button type="submit" name="employee_add_button"><a href="employeeRegister.php">Add</button></td>
                    <td><button type="submit" name="employee_show_button">Show</button></td>
                </tr>
            </table>
            <br>
            <hr><br>
            <!-- Customer ordering Table -->
            <table border="1">
                <tr>
                    <th colspan="5">
                        <h3>Coustomer Order</h3>
                    </th>
                </tr>
                <tr>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Total price</th>
                    <th>View button</th>
                </tr>
                <?php while ($row = mysqli_fetch_assoc($customerResult)) { ?>
                    <tr>
                        <td><?php echo $row["Email"]; ?></td>
                        <td><?php echo $row["Name"]; ?></td>
                        <td><?php echo $row["Address"]; ?></td>
                        <td><?php echo $row["Total Price"]; ?></td>
                        <td><button type="submit" name="order_view_button">View</button></td>
                    </tr>
                <?php } ?>
            </table><br>
            <hr>
        </form>
    </fieldset>

</body>

</html>