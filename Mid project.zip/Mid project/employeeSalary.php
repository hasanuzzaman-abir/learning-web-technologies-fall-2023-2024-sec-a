<?php
// session_start();
// Include database connection
include_once('database.php');
// checking is the button pressed or not
if (isset($_POST['enter'])) {
    $email = $_POST['email'];
    $hourlySalary = $_POST['salary'];
    $bonous = $_POST['bonous_salary'];
    // check empty or not
    if (empty($email && $hourlySalary && $bonous)) {
        echo "Fill the it properly";
    } else {
        // salary calculation
        $grossSalary = $hourlySalary * $bonous * 10;
        // SQL Quearry
        $salarySql = "INSERT INTO salary_table VALUES ('$email', '$hourlySalary', '$bonous', '$grossSalary')";
        // execution of quearry
        $salaryResult = mysqli_query($connection, $salarySql);
        // Checking for successful data insertion
        if ($salaryResult) {
            echo "Data inserted successfully";
        } else {
            echo "There was an error";
        }
    }
}
if (isset($_POST['back'])) {
    header("location: home.php");
}
if (isset($_POST['enter'])) {
    header("location: home.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Employee Salary</title>
</head>

<body>
    <fieldset>
        <form action="" method="post">
            <br>
            <button type="submit" name="back">Back</button>
            <hr><br>
            <!-- email -->
            Email: <input type="text" name="email"> <br>
            <hr>
            <!-- Hourly salary -->
            Hourly Salary: <input type="text" name="salary" placeholder="10 Hour"> <br>
            <hr>
            <!-- Bonous salary -->
            Bonous Salary: <input type="text" name="bonous_salary"> <br>
            <hr>
            <button type="submit" name="enter">Enter</button>
    </fieldset>
    </form>
    </fieldset>
</body>

</html>