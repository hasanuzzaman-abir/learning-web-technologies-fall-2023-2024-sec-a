<?php
// session_start();
// Include database connection
include_once('database.php');
// SQL quearry
$showEmployeeSql = "SELECT * FROM employee_table";
//Run SQL quearry
$showEmployeeResult = mysqli_query($connection, $showEmployeeSql);

if (isset($_POST['back'])) {
    header("location: home.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
</head>

<body>
    <form action="" method="post">
        <fieldset>
            <br>
            <button type="submit" name="back">Back</button>
            <hr><br>
            <table>
                <table border="1">
                    <tr>
                        <th colspan="4">
                            <h3>Employee Recent Added</h3>
                        </th>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Date of joining</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($showEmployeeResult)) { ?>
                        <tr>
                            <td><?php echo $row["Email"]; ?></td>
                            <td><?php echo $row["Name"]; ?></td>
                            <td><?php echo $row["Status"]; ?></td>
                            <td><?php echo $row["Date"]; ?></td>
                        </tr>
                    <?php } ?>
                </table>
        </fieldset>
    </form>
</body>

</html>