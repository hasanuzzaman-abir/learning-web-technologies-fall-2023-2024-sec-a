<?php
// session_start();
// Include database connection
include_once('database.php');
// SQL quearry
$employeeSql = "SELECT *
    FROM user_table
    WHERE Date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY);";
// Run SQL quearry
$employeeResult = mysqli_query($connection, $employeeSql);

if (isset($_POST['back'])) {
    header("location: home.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Document</title>
</head>

<body>
    <form action="" method="post">
        <fieldset>
            <br>
            <button type="submit" name="back">Back</button>
            <hr><br>
            <!-- Recently Employee Added -->
            <table>
                <table border="1">
                    <tr>
                        <th colspan="3">
                            <h3>Employee Recent Added</h3>
                        </th>
                    </tr>
                    <!-- Table Head -->
                    <tr>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Date of joining</th>
                    </tr>
                    <!-- Showing Table Data With Database value -->
                    <?php while ($row = mysqli_fetch_assoc($employeeResult)) { ?>
                        <tr>
                            <td><?php echo $row["Email"]; ?></td>
                            <td><?php echo $row["Name"]; ?></td>
                            <td><?php echo $row["Date"]; ?></td>
                        </tr>
                    <?php } ?>
                </table>
        </fieldset>
    </form>
</body>

</html>