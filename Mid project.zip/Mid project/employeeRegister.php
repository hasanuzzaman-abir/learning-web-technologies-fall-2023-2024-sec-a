<?php
// Include database connection
include_once('database.php');
// checking is the register button is clicked or not
if (isset($_POST['register'])) {
    // storing value in php variable
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $status = $_POST['status'];
    $date = date('Y-m-d', strtotime($_POST['dateofjoin']));
    if (empty($name && $email && $phoneNumber && $password && $status && $date)) {
        echo "Fill the form properly";
    } else {
        // SQL quearry
        $sql = "INSERT INTO employee_table VALUES ('$name', '$email', '$password', '$status', '$date')";
        // Run quearry
        $result = mysqli_query($connection, $sql);
        // Checking for successful data insertion
        if ($result) {
            echo "Data inserted successfully";
            header("location: home.php");
        } else {
            echo "There was an error";
        }
    }
}
if (isset($_POST['back'])) {
    header("location: home.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Register</title>
</head>

<body>
    <div style="text-align: center;">
        <form action="" method="post">
            <fieldset>
                <!-- heading -->
                <h1>Employee Register</h1>
                <br>
                <!-- name -->
                Name: <input type="text" name="name"> <br>
                <hr>
                <!-- email -->
                Email: <input type="text" name="email"> <br>
                <hr>
                <!-- password -->
                Password: <input type="text" name="password"> <br>
                <hr>
                <!-- Phone Number -->
                Status: <input type="text" name="status"> <br>
                <hr>
                Joining Date:
                <input type="date" name="dateofjoin" /><br>
                <hr>
                <!-- submit button -->
                <button type="submit" name="register">Register</button>
                <button type="submit" name="back">Back</button>
            </fieldset>
        </form>
    </div>
</body>

</html>