<?php
// session_start();
// Include database connection
include_once('database.php');
// SQL quearry
$employeeSql = "SELECT *
    FROM employee_table
    WHERE Date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY);";
//Run SQL quearry
$employeeResult = mysqli_query($connection, $employeeSql);

if (isset($_POST['back'])) {
    header("location: home.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form action="" method="post">
        <fieldset>
            <br>
            <button type="submit" name="back">Back</button>
            <hr><br>
            <table>
                <table border="1">
                    <tr>
                        <th colspan="3">
                            <h3>Employee Recent Added</h3>
                        </th>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Date of joining</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($employeeResult)) { ?>
                        <tr>
                            <td><?php echo $row["Email"]; ?></td>
                            <td><?php echo $row["Name"]; ?></td>
                            <td><?php echo $row["Date"]; ?></td>
                        </tr>
                    <?php } ?>
                </table>
        </fieldset>
    </form>
</body>

</html>