<?php
// Session start
// session_start();
// Include database connection
include_once('database.php');
// checking is the login button is clicked or not
if (isset($_POST['login'])) {
    // storing value in php variable
    $email = $_POST['email'];
    $password = $_POST['password'];
    if (empty($email || $password)) {
        echo "Fill it properly";
    } else {
        // quearry
        $sql = "SELECT Email FROM user_table WHERE email = '$email' and password = '$password'";
        // execution of quearry
        $result = mysqli_query($connection, $sql);
        if ($result->num_rows > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $_SESSION['email'] = $row["Email"];
                header("location: home.php");
            }
        } else {
            echo "There was an error Try again";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
</head>

<body>
    <div style="text-align: center;">
        <form action="" method="post">
            <fieldset>
                <!-- heading -->
                <h1>Login</h1>
                <!-- email -->
                Email: <input type="text" name="email"> <br>
                <hr>
                <!-- password -->
                Password: <input type="password" name="password"> <br>
                <hr>
                <!-- login button -->
                <button type="submit" name="login">Login</button>
                <!-- register button -->
                <button type="submit" name="register"><a href="resigtration.php">Register</button>

            </fieldset>
        </form>
    </div>
</body>

</html>