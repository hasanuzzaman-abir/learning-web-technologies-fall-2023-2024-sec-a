<?php
// session_start();
// Include database connection
include_once('database.php');

if (isset($_POST['back'])) {
    header("location: home.php");
}
// Revenue calculation
// SQL Quearry
$revenueSql = "SELECT SUM(Total Price) as total_revenue FROM coustomer_order";
// Run SQL quearry
$revenueResult = mysqli_query($connection, $revenueSql);
$revenueRow = mysqli_fetch_assoc($revenueResult);
// store value in php variable
$totalRevenue = $revenueRow['total_revenue'];

// Expences calculation
// SQL Quearry
$expensesSql = "SELECT SUM(Total Salary) as total_expences FROM salary_table";
// Run SQL quearry
$expensesResult = mysqli_query($connection, $expensesSql);
$expensesRow = mysqli_fetch_assoc($expensesResult);
// store value in php variable
$totalExpenses = $expensesRow['total_expences'];

// profit calculation
$profit = $totalRevenue - $totalExpenses;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profit Calculation</title>
</head>

<body>
    <h1>Profit Calculation</h1>
    <?php
    echo "Total Revenue: $totalRevenue<br>";
    echo "Total Expenses: $totalExpenses<br>";
    echo "Profit: $profit<br>";
    ?>
</body>

</html>